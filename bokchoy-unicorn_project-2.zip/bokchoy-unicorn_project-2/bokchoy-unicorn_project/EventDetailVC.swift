//
//  EventDetailVC.swift
//  bokchoy-unicorn_project
//
//  Created by Verdande on 7/3/19.
//  Copyright © 2019 Jasmine Li. All rights reserved.
//

import UIKit

class EventDetailVC: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    
    
    public var eventData : Dictionary<String, Any> = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //changing the titleLabel doesn't work yet...
        //I suspect it's because the IBOutlet above is not truly connected, but I haven't figured out how to do so...
       // titleLabel.text = eventData["title"] as! String
        self.titleLabel.text = "here is a title lolol"
        //self.detailLabel.text = "details blablablabla"
    }
    
    //@IBAction func interested(_ sender: Any) {
    //}
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
